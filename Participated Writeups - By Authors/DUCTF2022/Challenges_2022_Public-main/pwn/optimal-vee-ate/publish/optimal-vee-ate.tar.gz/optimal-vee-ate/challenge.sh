#!/bin/bash
./d8 --no-wasm-write-protect-code-memory ./worker.js

